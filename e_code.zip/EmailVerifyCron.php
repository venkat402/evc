<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'GuzzleHttp/vendor/autoload.php';

use GuzzleHttp\Pool;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;

$client = new Client(['timeout' => 1200]);

require_once 'Validation.php';



$run_email_validation = new Validation();
// setting email verify path url
$run_email_validation->pathUrl = "http://googlemailo.info/emailvalidator/verify_email.php?email=";

//test email
if (!empty($_GET['email'])) {
    $email = trim($_GET['email']);
    $run_email_validation->testEmail($email);
    die;
}
// technohrmmail.info main connection
$get_domains = $run_email_validation->getDatabases(
        "technohrmmail.info", "root", "QFTOCJg1QwsB4BaC", "zadmin_emails"
);
if (empty($get_domains)) {
    var_dump("Main Domain Connection problem");
    die;
}
//setup manual domain connection here (out side tracker domains)
$get_domains[] = Array
        (
            "domain_name" => "docmax.info",
            "user_name" =>  "root",
            "domain_password" =>  "S69VTFT5X3IDOs6P",
            "db_name" =>  "zadmin_emails",
        );

// start process
$run_email_validation->startProcess($get_domains);
