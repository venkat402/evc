<?php

	require_once 'email_validation.php';
	$validator = new email_validation_class;
	$validator->timeout = 10;
	$validator->data_timeout = 0;
	$validator->localuser = "info";
	$validator->localhost = "phpclasses.org";
	$validator->debug = 0;
	$validator->html_debug = 0;
        
        if(isset($_GET["email"])){
            $email=$_GET["email"];
	}
	
	
	$result = $validator->ValidateEmailBox(trim($email));
        echo $result;
	
	
