<?php

require_once 'GuzzleHttp/vendor/autoload.php';

use GuzzleHttp\Pool;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;

class Validation {

    public $server_conn;
    // set emailvalidation path url 
    public $pathUrl;

    public function testEmail($email) {
        $url = $this->pathUrl . $email;
        $result = file_get_contents($url);
        var_dump($result);
    }

    public function connect($dbCredentials) {
        $dbCredentials = array_map('trim', $dbCredentials);
        extract($dbCredentials);
        $conn = new mysqli($domain_name, $user_name, $domain_password, $db_name);
        if ($conn->connect_error) {
            return $conn;
        } else {
            $this->server_conn = $conn;
        }
        return $conn;
    }

    public function getLists() {
        $result = $this->server_conn->query("SELECT DISTINCT (list.list_id) FROM list_subscriber JOIN list ON list_subscriber.list_id = list.list_id AND list.status != 'pending-delete' WHERE list_subscriber.status = 'unconfirmed' GROUP BY list.list_id");

        if (!$result->num_rows > 0) {
            $this->noLists();
            return null;
        } else {
            while ($row = $result->fetch_assoc()) {
                $listIds[] = $row;
            }
        }
        return $listIds;
    }

    public function getEmails($listId, $limit) {
        if ($result = $this->server_conn->query("SELECT subscriber_id,email,status FROM list_subscriber WHERE status='unconfirmed' AND list_id='" . $listId['list_id'] . "' LIMIT $limit")) {
            return $result;
        } else {
            var_dump("select emails failed");
            return null;
        }
    }

    public function pooling($listIds) {
        $client = new Client(['timeout' => 1200]);
        $pathUrl = $this->pathUrl;
        // auto load files 
        if (count($listIds) > 0) {
            foreach ($listIds as $listId) {
                $allSubscribers = $this->getEmails($listId, 100);
                if ($allSubscribers->num_rows > 0) {
                    $this->emailverify($client, $allSubscribers);
                }
            }
        }
    }

    public function getSubscribers($allSubscribers) {
        foreach ($allSubscribers as $subscriber) {
            $pathUrl = $this->pathUrl . $subscriber['email'] . '&subscriber_id=' . $subscriber['subscriber_id'];
            yield new Request("GET", $pathUrl);
        }
    }

    public function emailverify($client, $allSubscribers) {
        $requests = $this->getSubscribers($allSubscribers);
        $pool = new Pool($client, $requests, [
            'concurrency' => 25,
            'fulfilled' => function ($response, $index) {
                $obj = json_decode($response->getBody());
                $result = $obj->result;
                $subscriber_id = $obj->subscriber_id;
                $email_id = $obj->email_id;
                if ($result == 0) {
                    $this->inValidEmail($result, $subscriber_id, $email_id);
                } else {
                    $this->validEmail($result, $subscriber_id, $email_id);
                }
            },
            'rejected' => function ($reason, $index) {
                // this is delivered each failed request
                print_r($reason);
                echo "Index: " . $index . "<br>";
                echo "Message" . $reason->getMessage() . "<br>";
            },
        ]);
        // Initiate the transfers and create a promise
        $promise = $pool->promise();
        // Force the pool of requests to complete.
        $promise->wait();
    }

    public function noLists() {
        $result = $this->server_conn->query("SELECT list_id,display_name,status FROM list WHERE status='verification-pending'");
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            extract($row);
            $this->server_conn->query("UPDATE list SET status='active' WHERE list_id = '$list_id'");
            var_dump("List : $display_name Status Active");
        }
        var_dump("No Lists Found");
        return NULL;
    }

    public function inValidEmail($result, $subscriber_id, $email_id) {
        if ($this->server_conn->query("UPDATE list_subscriber SET status='notexist' WHERE subscriber_id='$subscriber_id'")) {
            var_dump("Not Exist Email : $result Subscriber_id: $subscriber_id Email : $email_id");
        } else {
            var_dump("Email update status Failed");
        }
    }

    public function validEmail($result, $subscriber_id, $email_id) {
        if ($this->server_conn->query("UPDATE list_subscriber SET status='confirmed' WHERE subscriber_id='$subscriber_id'")) {
            var_dump("Exist Email : $result Subscriber_id: $subscriber_id Email : $email_id");
        } else {
            var_dump("Email status update failed");
        }
    }

    public static function getDatabases($serverName, $userName, $mysql_pass, $database) {
        //email address of server
        $con = new mysqli("$serverName", "$userName", "$mysql_pass", "$database");
        // Check connection
        if (!$con->ping()) {
            echo "Failed to connect to MySQL: " . $con->connect_error;
            die;
        }
        $result = $con->query("SELECT domain_name,user_name,domain_password,db_name FROM domains_info");
        while ($row = $result->fetch_assoc()) {
            $get_domains[] = $row;
        }
        $con->close();
        return $get_domains;
    }

    public function close_connection($conn) {
        $conn->close();
    }

    public function startProcess($get_domains) {
        foreach ($get_domains as $get_domain) {
            $conn = $this->connect($get_domain);
            if (!$conn) {
                var_dump($conn->connect_error);
                continue;
            } else {
                var_dump($get_domain['domain_name'] . ' connected');
            }
            $listIds = $this->getLists();
            if (!empty($listIds)) {
                $this->pooling($listIds);
            } else {
                continue;
            }
            unset($conn);
            unset($get_domain);
        }
    }

} 
